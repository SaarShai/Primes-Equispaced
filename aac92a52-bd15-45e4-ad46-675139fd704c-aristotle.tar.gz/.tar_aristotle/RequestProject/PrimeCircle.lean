import Mathlib

/-!
# Prime Circle Visualization: Formal Theorems

This file formalizes the core mathematical claims arising from visualizing
integers as fractions (1/n) in a circle, where each 1/n creates n equally-spaced
radii at positions k/n for k = 0, 1, …, n−1.

## Main Results

1. **Primes introduce only new radii**: `prime_iff_totient` — n ≥ 2 is prime iff φ(n) = n−1.
2. **Composites always overlap**: `composite_has_overlap` — composite n always has
   a radius coinciding with one from a smaller division.
3. **New radii count is Euler's totient**: The number of genuinely new radii for 1/n
   (excluding position 0) is exactly φ(n).
4. **Farey count**: |F_N| = 1 + Σ φ(k) for k = 1..N.
5. **Euler's product formula**: φ(n) = n · ∏_{p|n} (1 - 1/p).
-/

open Nat

/-! ## Part 1: Prime characterization via Euler's totient -/

/-- A natural number n ≥ 2 is prime if and only if φ(n) = n - 1.
This formalizes the observation that primes introduce only new radii
in the circle visualization. -/
theorem prime_iff_totient (n : ℕ) (hn : 2 ≤ n) :
    Nat.Prime n ↔ n.totient = n - 1 :=
  ⟨fun h => Nat.totient_prime h, fun h => (Nat.totient_eq_iff_prime (by linarith)).1 h⟩

/-! ## Part 2: Composites always have overlapping radii -/

/-- For a composite number n, there exists k with 0 < k < n such that
gcd(k, n) > 1, meaning the radius at position k/n coincides with a
radius from a smaller circle division. -/
theorem composite_has_overlap (n : ℕ) (hn : 2 ≤ n) (hnp : ¬ Nat.Prime n) :
    ∃ k, 0 < k ∧ k < n ∧ Nat.gcd k n > 1 := by
  contrapose! hnp
  exact Nat.prime_def_lt'.mpr ⟨hn, fun p hp₁ hp₂ hp₃ =>
    not_lt_of_ge (hnp p (by linarith) (by linarith))
      (Nat.lt_of_le_of_ne (Nat.gcd_pos_of_pos_right _ (by linarith))
        (Ne.symm <| by have := Nat.gcd_eq_left hp₃; aesop))⟩

/-- For a prime p, every k with 0 < k < p has gcd(k, p) = 1,
meaning all radii are new. -/
theorem prime_all_radii_new (p : ℕ) (hp : Nat.Prime p) (k : ℕ)
    (hk1 : 0 < k) (hk2 : k < p) : Nat.gcd k p = 1 :=
  Nat.Coprime.symm <| hp.coprime_iff_not_dvd.mpr <| Nat.not_dvd_of_pos_of_lt hk1 hk2

/-! ## Part 3: Totient counts new radii -/

/-- The totient φ(n) counts exactly the number of positions k ∈ {1, ..., n-1}
that are coprime to n, i.e., the number of new radii. -/
theorem totient_eq_card_coprime (n : ℕ) (_hn : 0 < n) :
    n.totient = (Finset.filter (fun k => Nat.Coprime k n) (Finset.range n)).card :=
  congr_arg Finset.card (Finset.filter_congr fun x _hx => by rw [Nat.coprime_comm])

/-! ## Part 4: Farey sequence properties -/

/-- For consecutive Farey fractions a/b < c/d in F_N, bc - ad = 1.
This is a classical result in the theory of Farey sequences; it encodes the
"repulsion" property that prevents Farey fractions from clustering. -/
private lemma mul_sub_self_eq (a g : ℕ) : g * a - a = a * (g - 1) := by
  cases g with | zero => simp | succ n => simp [Nat.succ_mul]; ring

private lemma mediant_left_ineq (a b c d g : ℕ) (hlt : a * d < b * c)
    (hg : 0 < g) (hgac : g ∣ (a + c)) (hgbd : g ∣ (b + d)) :
    a * ((b + d) / g) ≤ b * ((a + c) / g) := by
  obtain ⟨x, hx⟩ := hgac; obtain ⟨y, hy⟩ := hgbd
  rw [hx, hy, Nat.mul_div_cancel_left _ hg, Nat.mul_div_cancel_left _ hg]
  suffices (a : ℤ) * y ≤ b * x by exact_mod_cast this
  nlinarith [show (a : ℤ) + c = g * x by exact_mod_cast hx,
             show (b : ℤ) + d = g * y by exact_mod_cast hy,
             show (a : ℤ) * d < b * c by exact_mod_cast hlt,
             show (0 : ℤ) < g by exact_mod_cast hg]

private lemma mediant_right_ineq (a b c d g : ℕ) (hlt : a * d < b * c)
    (hg : 0 < g) (hgac : g ∣ (a + c)) (hgbd : g ∣ (b + d)) :
    d * ((a + c) / g) ≤ c * ((b + d) / g) := by
  obtain ⟨x, hx⟩ := hgac; obtain ⟨y, hy⟩ := hgbd
  rw [hx, hy, Nat.mul_div_cancel_left _ hg, Nat.mul_div_cancel_left _ hg]
  suffices (d : ℤ) * x ≤ c * y by exact_mod_cast this
  nlinarith [show (a : ℤ) + c = g * x by exact_mod_cast hx,
             show (b : ℤ) + d = g * y by exact_mod_cast hy,
             show (a : ℤ) * d < b * c by exact_mod_cast hlt,
             show (0 : ℤ) < g by exact_mod_cast hg]

/-- If the reduced mediant equals a/b, then coprimality of c/d forces g = 2
and c = a, d = b, contradicting a/b < c/d. -/
private lemma coprime_contr_left (a b c d g : ℕ) (hg2 : 2 ≤ g) (hlt : a * d < b * c)
    (hcop : Nat.Coprime c d) (hac : g * a = a + c) (hbd : g * b = b + d) : False := by
  have hc : c = a * (g - 1) := by
    rw [show c = g * a - a from by omega, mul_sub_self_eq]
  have hd' : d = b * (g - 1) := by
    rw [show d = g * b - b from by omega, mul_sub_self_eq]
  have : (g - 1) ∣ Nat.gcd c d :=
    Nat.dvd_gcd ⟨a, by rw [hc]; ring⟩ ⟨b, by rw [hd']; ring⟩
  rw [hcop.gcd_eq_one] at this
  have : g = 2 := by have := Nat.le_of_dvd Nat.one_pos this; omega
  subst this; simp at hc hd'; nlinarith

/-- Symmetric case: if reduced mediant equals c/d. -/
private lemma coprime_contr_right (a b c d g : ℕ) (hg2 : 2 ≤ g) (hlt : a * d < b * c)
    (hcop : Nat.Coprime a b) (hac : g * c = a + c) (hbd : g * d = b + d) : False := by
  have ha : a = c * (g - 1) := by
    rw [show a = g * c - c from by omega, mul_sub_self_eq]
  have hb' : b = d * (g - 1) := by
    rw [show b = g * d - d from by omega, mul_sub_self_eq]
  have : (g - 1) ∣ Nat.gcd a b :=
    Nat.dvd_gcd ⟨c, by rw [ha]; ring⟩ ⟨d, by rw [hb']; ring⟩
  rw [hcop.gcd_eq_one] at this
  have : g = 2 := by have := Nat.le_of_dvd Nat.one_pos this; omega
  subst this; simp at ha hb'; nlinarith

private lemma div_eq_mul_of_dvd (n g x : ℕ) (hg_dvd : g ∣ n) (h : n / g = x) :
    g * x = n := by
  have := Nat.div_mul_cancel hg_dvd; nlinarith

/-
PROBLEM
Bézout witness for coprime naturals: given coprime a, b with b > 0,
    there exist natural numbers p, q with b * p = a * q + 1,
    0 < q, q ≤ b, and gcd(p, q) = 1.

PROVIDED SOLUTION
Since gcd(a,b) = 1, by `hcop.isCoprime` we get `IsCoprime (a : ℤ) (b : ℤ)`, i.e., ∃ u v : ℤ, a*u + b*v = 1. Then b*v = 1 - a*u, so b*v + a*u = 1.

We want natural numbers p, q with b*p = a*q + 1 and 0 < q ≤ b.

From the IsCoprime witness: (a:ℤ)*u + (b:ℤ)*v = 1. Set s = v, t = -u. Then (b:ℤ)*s - (a:ℤ)*(-u) = b*s + a*u = b*v + a*u = 1... wait, let me be more careful.

(a:ℤ)*u + (b:ℤ)*v = 1 means (b:ℤ)*v = 1 - (a:ℤ)*u. Rearranging: (b:ℤ)*v - (a:ℤ)*(-u) = 1 is wrong.

Actually: (a:ℤ)*u + (b:ℤ)*v = 1 → (b:ℤ)*(-v) - (a:ℤ)*(-u) = -(a*u+b*v) = -1. Wrong sign.

Let me try: from a*u + b*v = 1, set the Bezout equation as b*(-v) + a*(-u) = -(a*u + b*v) = -1. Hmm.

OK: a*u + b*v = 1 → b*v = 1 - a*u → (b:ℤ) * v + (a:ℤ) * u = 1 + 2*(a:ℤ)*u... no.

Actually just: a*u + b*v = 1. We can read this as: b*v ≡ 1 (mod a) and a*u ≡ 1 (mod b).

Approach: Use `Nat.gcd_eq_gcd_ab` which gives `(a.gcd b : ℤ) = a * a.gcdA b + b * a.gcdB b`. Since a.gcd b = 1 (from hcop), we have `1 = (a:ℤ) * a.gcdA b + (b:ℤ) * a.gcdB b`.

Now let t = ((-a.gcdA b) % (b : ℤ)). Since b > 0, t ∈ [0, b-1]. If t = 0, then b | a.gcdA b, and from a*(a.gcdA b) + b*(a.gcdB b) = 1, we get a*0 ≡ 1 (mod b), so b = 1. Then take q = 1, p = a + 1 (check: 1*(a+1) = a*1 + 1 ✓).

If t > 0, then let q = t.toNat (which is in {1,...,b-1}). Then a*q ≡ -a*(a.gcdA b) ≡ 1 - b*(a.gcdB b) ≡ 1 (mod b)... hmm not quite. Let me re-derive.

From 1 = a * (gcdA a b) + b * (gcdB a b):
a * (gcdA a b) = 1 - b * (gcdB a b)
So a * (gcdA a b) ≡ 1 (mod b).
And a * (-(gcdA a b)) ≡ -1 (mod b).

I want b*p = a*q + 1, which means a*q ≡ -1 (mod b).
So q should be chosen so that q ≡ -(gcdA a b) (mod b)... wait, a*q ≡ -1 (mod b), and a*(gcdA a b) ≡ 1 (mod b), so a*(-(gcdA a b)) ≡ -1 (mod b). So q ≡ -(gcdA a b) (mod b).

Take q₀ = ((-(gcdA a b : ℤ)) % (b : ℤ)).toNat.
- If this is 0, set q = b (then a*b ≡ -1 (mod b) implies b | (a*b + 1), i.e., b | 1, so b = 1; take q = 1 = b, p = a + 1).
- If > 0, set q = q₀ which is in {1,...,b-1}.

Then p = (a*q + 1) / b, which is a natural number since b | (a*q + 1).
And gcd(p,q) = 1 because any common divisor divides b*p - a*q = 1.

This is the approach but it's fiddly. An alternative: use `Nat.exists_mul_emod_eq_one_of_coprime` or related lemmas. Or use ZMod.

Alternative simpler approach: Since gcd(a,b) = 1, the map k ↦ a*k mod b is a bijection on {0,...,b-1}. So there exists q ∈ {0,...,b-1} with a*q ≡ b-1 (mod b), i.e., a*q + 1 ≡ 0 (mod b). If q = 0 then b | 1 so b = 1; set q = 1. Otherwise q ∈ {1,...,b-1}. Set p = (a*q+1)/b.
-/
private lemma bezout_nat_witness (a b : ℕ) (hb : 0 < b) (hcop : Nat.Coprime a b) :
    ∃ p q : ℕ, b * p = a * q + 1 ∧ 0 < q ∧ q ≤ b ∧ Nat.Coprime p q := by
  -- Let $q$ be a number such that $a * q ≡ -1 \pmod{b}$ and $0 < q ≤ b$.
  obtain ⟨q, hq⟩ : ∃ q, a * q ≡ b - 1 [MOD b] ∧ 0 < q ∧ q ≤ b := by
    obtain ⟨q, hq⟩ : ∃ q, a * q ≡ b - 1 [MOD b] := by
      have := Nat.exists_mul_mod_eq_one_of_coprime hcop;
      rcases b with ( _ | _ | b ) <;> simp_all +decide [ Nat.ModEq ];
      · exact ⟨ 0, by norm_num ⟩;
      · exact ⟨ this.choose * ( b + 1 ), by rw [ ← mul_assoc, Nat.mul_mod, this.choose_spec.2 ] ; norm_num [ Nat.mod_eq_of_lt ] ⟩;
    refine' ⟨ q % b + if q % b = 0 then b else 0, _, _, _ ⟩ <;> split_ifs <;> simp_all +decide [ Nat.ModEq, Nat.mod_eq_of_lt ];
    · simp_all +decide [ Nat.mul_mod ];
    · exact Nat.pos_of_ne_zero ‹_›;
    · exact Nat.le_of_lt ( Nat.mod_lt _ hb );
  -- Let $p = \frac{a * q + 1}{b}$.
  obtain ⟨p, hp⟩ : ∃ p, b * p = a * q + 1 := by
    exact ⟨ ( a * q + 1 ) / b, Nat.mul_div_cancel' <| Nat.dvd_of_mod_eq_zero <| by rw [ Nat.add_mod, hq.left ] ; cases b <;> simp_all +decide ⟩
  use p, q, hp, hq.right.left, hq.right.right, ?_;
  by_contra h_not_coprime;
  obtain ⟨ k, hk ⟩ := Nat.Prime.not_coprime_iff_dvd.mp h_not_coprime;
  have := congr_arg ( · % k ) hp; norm_num [ Nat.add_mod, Nat.mul_mod, Nat.mod_eq_zero_of_dvd hk.2.1, Nat.mod_eq_zero_of_dvd hk.2.2 ] at this; rcases b with ( _ | _ | b ) <;> simp_all +decide ;

/-
PROBLEM
Given consecutive Farey fractions a/b < c/d with bc - ad ≥ 2, both coprime,
    there exists a coprime fraction p/q strictly between a/b and c/d
    with q ≤ max(b,d). This contradicts consecutiveness.

PROVIDED SOLUTION
Use dual Bezout witnesses. Set m := b * c - a * d (so m ≥ 2 from hk2).

Step 1: From bezout_nat_witness(a, b, hb, hcop1), get p₁, q₁ with b*p₁ = a*q₁ + 1, 0 < q₁ ≤ b, Coprime p₁ q₁.

Step 2: Have c_pos : 0 < c (from hlt: if c = 0 then a*d < 0, impossible for ℕ, use omega).

Step 3: From bezout_nat_witness(d, c, c_pos, hcop2.symm), get P₂, Q₂ with c*P₂ = d*Q₂ + 1, 0 < Q₂ ≤ c, Coprime P₂ Q₂.

Now do by_cases on q₁ * m > d (use Nat.lt_or_ge or omega).

CASE 1: q₁ * m > d. Use witness ⟨p₁, q₁⟩.
- 0 < q₁: given.
- q₁ ≤ max b d: from q₁ ≤ b and b ≤ max b d.
- Coprime p₁ q₁: given.
- a * q₁ ≤ b * p₁: from b*p₁ = a*q₁ + 1, so b*p₁ > a*q₁, use omega.
- c * q₁ ≥ d * p₁: Key identity: b*(c*q₁ - d*p₁) = q₁*m - d. Proof: b*c*q₁ - d*(a*q₁+1) = q₁*(b*c - a*d) - d = q₁*m - d. Since q₁*m > d, the RHS > 0. Since b > 0, c*q₁ - d*p₁ > 0. Use omega or nlinarith with the identity.
- ¬(p₁ = a ∧ q₁ = b): if p₁ = a and q₁ = b, then b*a = a*b + 1, contradiction. Use omega.
- ¬(p₁ = c ∧ q₁ = d): if p₁ = c and q₁ = d, then b*c = a*d + 1, so m = 1 < 2. Use omega.

CASE 2: q₁ * m ≤ d.

First show c ≥ 2. If c = 0: from hlt, a*d < 0, impossible. If c = 1: from b*p₁ = a*q₁ + 1 and p₁ ≥ 1 (since b*p₁ ≥ 1): a*q₁ ≥ b - 1. Since c = 1: m = b - a*d ≥ 2, so b ≥ a*d + 2. Thus a*q₁ ≥ a*d + 1. If a = 0: 0 ≥ 1, contradiction. So a ≥ 1, and a*q₁ > a*d implies q₁ > d (since a > 0), so q₁ ≥ d + 1. Then q₁*m ≥ 2*(d+1) > d, contradicting q₁*m ≤ d.
So c ≥ 2.

Since c ≥ 2 and Q₂ ≤ c: Q₂ ≤ c - 1 (because if Q₂ = c then c*P₂ = d*c + 1 means c divides 1, so c = 1, contradicting c ≥ 2). Then P₂ = (d*Q₂+1)/c ≤ (d*(c-1)+1)/c ≤ d (since d*(c-1)+1 ≤ d*c iff 1 ≤ d, which is true from hd).

Now by_cases on Q₂ * m > a.

CASE 2a: Q₂ * m > a. Use witness ⟨Q₂, P₂⟩.
- 0 < P₂: since c*P₂ = d*Q₂ + 1 ≥ 1 and c ≥ 1, P₂ ≥ 1.
- P₂ ≤ max b d: from P₂ ≤ d ≤ max b d.
- Coprime Q₂ P₂: need Coprime P₂ Q₂ from bezout, then use Nat.Coprime.symm.
  Actually bezout_nat_witness gives Coprime P₂ Q₂, and we need Coprime Q₂ P₂ = Nat.Coprime Q₂ P₂ = Nat.Coprime.symm applied.
- a * P₂ ≤ b * Q₂: identity c*(b*Q₂ - a*P₂) = Q₂*m - a. Since Q₂*m > a, RHS > 0, and c > 0, so b*Q₂ > a*P₂.
- c * P₂ ≥ d * Q₂: from c*P₂ = d*Q₂ + 1. Use omega.
- ¬(Q₂ = a ∧ P₂ = b): if so, c*b = d*a + 1, so m = 1 < 2. Use omega.
- ¬(Q₂ = c ∧ P₂ = d): if so, c*d = d*c + 1, i.e., 0 = 1. Use omega.

CASE 2b: Q₂ * m ≤ a. Derive False (algebraic contradiction).
Key identity: b*c*(p₁*P₂ - Q₂*q₁) = a*q₁ + d*Q₂ + 1 - m*q₁*Q₂.
Proof of identity: b*c*p₁*P₂ = c*P₂*(a*q₁+1) = (d*Q₂+1)*(a*q₁+1) = a*d*q₁*Q₂ + a*q₁ + d*Q₂ + 1. And b*c*Q₂*q₁ = b*c*Q₂*q₁. So b*c*(p₁*P₂ - Q₂*q₁) = a*d*q₁*Q₂ + a*q₁ + d*Q₂ + 1 - b*c*q₁*Q₂ = a*q₁ + d*Q₂ + 1 - (b*c - a*d)*q₁*Q₂ = a*q₁ + d*Q₂ + 1 - m*q₁*Q₂.

From q₁*m ≤ d: m*q₁*Q₂ ≤ d*Q₂. So a*q₁ + d*Q₂ + 1 - m*q₁*Q₂ ≥ a*q₁ + 1 > 0.
So p₁*P₂ > Q₂*q₁ (since b*c > 0). Thus p₁*P₂ - Q₂*q₁ ≥ 1.
Hence b*c ≤ a*q₁ + d*Q₂ + 1 - m*q₁*Q₂.

From q₁*m ≤ d: multiply both sides by Q₂*m: m²*q₁*Q₂ ≤ m*d*Q₂.
From Q₂*m ≤ a: multiply both sides by q₁*m: m²*q₁*Q₂ ≤ m*a*q₁.
So m*(a*q₁ + d*Q₂) ≥ 2*m²*q₁*Q₂.

We have m*b*c ≤ m*(a*q₁ + d*Q₂ + 1 - m*q₁*Q₂)
= m*a*q₁ + m*d*Q₂ + m - m²*q₁*Q₂
≤ 2*m*d*Q₂ + m - m²*q₁*Q₂  (wait, this isn't right)

Actually: m*(a*q₁ + d*Q₂) ≤ 2*a*d (from m*a*q₁ ≤ a*d and m*d*Q₂ ≤ a*d, by multiplying the hypotheses by d and a respectively... wait let me redo).

From q₁*m ≤ d, multiply by a: a*m*q₁ ≤ a*d. So m*a*q₁ ≤ a*d.
From Q₂*m ≤ a, multiply by d: d*m*Q₂ ≤ a*d. So m*d*Q₂ ≤ a*d.
Adding: m*(a*q₁ + d*Q₂) ≤ 2*a*d.

So m*b*c ≤ m*(a*q₁ + d*Q₂ + 1) - m²*q₁*Q₂ ≤ 2*a*d + m - m²*q₁*Q₂ ≤ 2*a*d + m - m² (since q₁*Q₂ ≥ 1).

But b*c = a*d + m. So m*(a*d + m) ≤ 2*a*d + m - m².
m*a*d + m² ≤ 2*a*d + m - m².
a*d*(m - 2) + 2*m² - m ≤ 0.
a*d*(m - 2) + m*(2*m - 1) ≤ 0.

Since m ≥ 2: m - 2 ≥ 0 and a*d ≥ 0. Also m*(2*m-1) ≥ 2*3 = 6 > 0. So LHS > 0. Contradiction!

Use nlinarith or omega with all these inequalities to derive False.
-/
private lemma exists_fraction_between (a b c d : ℕ) (hb : 0 < b) (hd : 0 < d)
    (hcop1 : Nat.Coprime a b) (hcop2 : Nat.Coprime c d)
    (hlt : a * d < b * c) (hk2 : 2 ≤ b * c - a * d) :
    ∃ p q : ℕ, 0 < q ∧ q ≤ max b d ∧ Nat.Coprime p q ∧
      a * q ≤ b * p ∧ c * q ≥ d * p ∧ ¬(p = a ∧ q = b) ∧ ¬(p = c ∧ q = d) := by
  -- Set m := b * c - a * d
  set m := b * c - a * d with hm;
  -- From Lemma 2, obtain p₁, q₁ such that b * p₁ = a * q₁ + 1 and 0 < q₁ ≤ b, and p₁ and q₁ are coprime.
  obtain ⟨p₁, q₁, hp₁q₁, hq₁_pos, hq₁_le_b, hp₁q₁_coprime⟩ : ∃ p₁ q₁ : ℕ, b * p₁ = a * q₁ + 1 ∧ 0 < q₁ ∧ q₁ ≤ b ∧ Nat.Coprime p₁ q₁ := by
    exact bezout_nat_witness a b hb hcop1;
  by_cases hq₁m : q₁ * m > d;
  · refine' ⟨ p₁, q₁, hq₁_pos, _, hp₁q₁_coprime, _, _, _, _ ⟩ <;> try linarith [ le_max_left b d, le_max_right b d ] ;
    · nlinarith [ Nat.sub_add_cancel hlt.le ];
    · grind;
    · grind;
  · -- From Lemma 2, obtain P₂, Q₂ such that c * P₂ = d * Q₂ + 1 and 0 < Q₂ ≤ c, and P₂ and Q₂ are coprime.
    obtain ⟨P₂, Q₂, hP₂Q₂, hQ₂_pos, hQ₂_le_c, hP₂Q₂_coprime⟩ : ∃ P₂ Q₂ : ℕ, c * P₂ = d * Q₂ + 1 ∧ 0 < Q₂ ∧ Q₂ ≤ c ∧ Nat.Coprime P₂ Q₂ := by
      have := bezout_nat_witness d c ( by nlinarith ) ( Nat.Coprime.symm hcop2 ) ; aesop;
    by_cases hQ₂m : Q₂ * m > a;
    · refine' ⟨ Q₂, P₂, _, _, _, _, _, _ ⟩ <;> try linarith;
      · nlinarith only [ hP₂Q₂, hQ₂_pos, hQ₂_le_c, hd ];
      · rcases c with ( _ | _ | c ) <;> rcases d with ( _ | _ | d ) <;> norm_num at *;
        · grind;
        · interval_cases Q₂ ; simp_all +decide;
          rcases a with ( _ | _ | a ) <;> norm_num at *;
          · linarith;
          · linarith;
          · nlinarith only [ hlt ];
        · exact Or.inl ( by nlinarith only [ hP₂Q₂, hQ₂_le_c, hq₁m, hk2, hq₁_pos, hq₁_le_b ] );
        · exact Classical.or_iff_not_imp_left.2 fun h => by nlinarith only [ h, hP₂Q₂, hq₁m, hQ₂m, hQ₂_le_c, hlt ] ;
      · exact hP₂Q₂_coprime.symm;
      · nlinarith only [ hP₂Q₂, hQ₂m, hq₁m, hlt, Nat.sub_add_cancel hlt.le ];
      · grind;
    · -- From the key identity, we have $b * c * (p₁ * P₂ - Q₂ * q₁) = a * q₁ + d * Q₂ + 1 - m * q₁ * Q₂$.
      have h_identity : b * c * (p₁ * P₂ - Q₂ * q₁) = a * q₁ + d * Q₂ + 1 - m * q₁ * Q₂ := by
        rw [ Nat.mul_sub_left_distrib ];
        rw [ tsub_eq_of_eq_add ];
        zify at *;
        rw [ Nat.cast_sub ] <;> push_cast <;> repeat nlinarith only [ hlt, hp₁q₁, hP₂Q₂, hq₁m, hQ₂m ] ;
        grind;
      -- From the identity, we have $b * c \leq a * q₁ + d * Q₂ + 1 - m * q₁ * Q₂$.
      have h_bc_le : b * c ≤ a * q₁ + d * Q₂ + 1 - m * q₁ * Q₂ := by
        refine' Nat.le_of_dvd ( Nat.sub_pos_of_lt _ ) ( h_identity ▸ dvd_mul_right _ _ );
        nlinarith only [ mul_pos hq₁_pos hQ₂_pos, hq₁m, hQ₂m, hk2 ];
      -- From the inequalities $q₁ * m ≤ d$ and $Q₂ * m ≤ a$, we can derive $m * a * q₁ ≤ a * d$ and $m * d * Q₂ ≤ a * d$.
      have h_ineq1 : m * a * q₁ ≤ a * d := by
        nlinarith only [ hq₁m, hQ₂m, hq₁_pos, hQ₂_pos ]
      have h_ineq2 : m * d * Q₂ ≤ a * d := by
        nlinarith only [ hQ₂m, hd ];
      -- Adding the inequalities $m * a * q₁ ≤ a * d$ and $m * d * Q₂ ≤ a * d$, we get $m * (a * q₁ + d * Q₂) ≤ 2 * a * d$.
      have h_sum_ineq : m * (a * q₁ + d * Q₂) ≤ 2 * a * d := by
        grind;
      -- Substitute $b * c = a * d + m$ into the inequality $b * c \leq a * q₁ + d * Q₂ + 1 - m * q₁ * Q₂$.
      have h_subst : a * d + m ≤ a * q₁ + d * Q₂ + 1 - m * q₁ * Q₂ := by
        rwa [ Nat.add_sub_of_le hlt.le ];
      rw [ Nat.le_sub_iff_add_le ] at h_subst;
      · nlinarith only [ hk2, h_subst, h_sum_ineq, h_ineq1, h_ineq2, show 0 < a * q₁ by exact mul_pos ( Nat.pos_of_ne_zero ( by aesop_cat ) ) hq₁_pos, show 0 < d * Q₂ by exact mul_pos hd hQ₂_pos, show 0 < m * q₁ * Q₂ by exact mul_pos ( mul_pos ( Nat.pos_of_ne_zero ( by aesop_cat ) ) hq₁_pos ) hQ₂_pos ];
      · exact le_of_lt ( Nat.lt_of_sub_ne_zero ( by omega ) )

theorem farey_consecutive_det (a b c d : ℕ) (hb : 0 < b) (hd : 0 < d)
    (hcop1 : Nat.Coprime a b) (hcop2 : Nat.Coprime c d)
    (hN : b + d > max b d)
    (hlt : a * d < b * c)
    (hcons : ∀ p q : ℕ, 0 < q → q ≤ max b d → Nat.Coprime p q →
      a * q ≤ b * p → c * q ≥ d * p → (p = a ∧ q = b) ∨ (p = c ∧ q = d)) :
    b * c - a * d = 1 := by
  by_contra h
  have hk2 : 2 ≤ b * c - a * d := by omega
  -- Consider the reduced mediant: divide (a+c, b+d) by their gcd
  set g := (a + c).gcd (b + d) with hg_def
  have hg_dvd_ac := Nat.gcd_dvd_left (a + c) (b + d)
  have hg_dvd_bd := Nat.gcd_dvd_right (a + c) (b + d)
  have hg_pos : 0 < g := Nat.gcd_pos_of_pos_left _ (by nlinarith : 0 < a + c)
  have hcop_pq : Nat.Coprime ((a + c) / g) ((b + d) / g) :=
    Nat.coprime_div_gcd_div_gcd hg_pos
  have hq_pos : 0 < (b + d) / g :=
    Nat.div_pos (Nat.le_of_dvd (by omega) hg_dvd_bd) hg_pos
  -- g divides bc - ad (key identity: b(a+c) - a(b+d) = bc - ad)
  have hg_dvd_k : g ∣ (b * c - a * d) := by
    have h1 := dvd_mul_of_dvd_right hg_dvd_ac b
    have h2 := dvd_mul_of_dvd_right hg_dvd_bd a
    have h3 : b * (a + c) - a * (b + d) = b * c - a * d := by
      zify [show a * (b + d) ≤ b * (a + c) from by nlinarith,
            show a * d ≤ b * c from by omega]; ring
    rw [← h3]; exact Nat.dvd_sub h1 h2
  by_cases hg2 : 2 ≤ g
  · -- Case g ≥ 2: reduced mediant has denominator ≤ max(b,d)
    have hq_le : (b + d) / g ≤ max b d := by
      calc (b + d) / g ≤ (b + d) / 2 := Nat.div_le_div_left hg2 (by omega)
        _ ≤ max b d := by omega
    -- The reduced mediant lies between a/b and c/d
    have hml := mediant_left_ineq a b c d g hlt hg_pos hg_dvd_ac hg_dvd_bd
    have hmr := mediant_right_ineq a b c d g hlt hg_pos hg_dvd_ac hg_dvd_bd
    -- Apply consecutiveness: the reduced mediant must equal a/b or c/d
    rcases hcons _ _ hq_pos hq_le hcop_pq hml hmr with ⟨hp_eq, hq_eq⟩ | ⟨hp_eq, hq_eq⟩
    · -- (a+c)/g = a and (b+d)/g = b → contradiction via coprimality of c/d
      exact coprime_contr_left a b c d g hg2 hlt hcop2
        (div_eq_mul_of_dvd _ _ _ hg_dvd_ac hp_eq) (div_eq_mul_of_dvd _ _ _ hg_dvd_bd hq_eq)
    · -- (a+c)/g = c and (b+d)/g = d → contradiction via coprimality of a/b
      exact coprime_contr_right a b c d g hg2 hlt hcop1
        (div_eq_mul_of_dvd _ _ _ hg_dvd_ac hp_eq) (div_eq_mul_of_dvd _ _ _ hg_dvd_bd hq_eq)
  · -- Case g = 1: use Bézout witnesses to find a fraction between a/b and c/d
    obtain ⟨p, q, hq_pos', hq_le, hcop_pq', hle, hge, hne1, hne2⟩ :=
      exists_fraction_between a b c d hb hd hcop1 hcop2 hlt hk2
    rcases hcons p q hq_pos' hq_le hcop_pq' hle hge with ⟨rfl, rfl⟩ | ⟨rfl, rfl⟩
    · exact hne1 ⟨rfl, rfl⟩
    · exact hne2 ⟨rfl, rfl⟩

/-! ## Part 5: Franel–Landau and the Riemann Hypothesis

The Franel–Landau theorem (1924) states:

  **RH ⟺ ∑_{j=1}^{|F_N|} |f_j - j/|F_N||² = O(N^{-1+ε}) for all ε > 0**

where f_1, ..., f_{|F_N|} are the Farey fractions in order.

This formalizes the "wobble minimization" interpretation: primes filling gaps
in the circle correspond to the Farey sequence approximating uniform distribution,
and the quality of this approximation is equivalent to the Riemann Hypothesis.
-/

/-- The number of Farey fractions up to order N equals 1 + ∑_{k=1}^{N} φ(k).
This connects the circle visualization directly to the Farey sequence:
each integer k contributes exactly φ(k) new radii. -/
theorem farey_count (N : ℕ) (_hN : 0 < N) :
    1 + ∑ k ∈ Finset.range N, (k + 1).totient =
    (Finset.filter (fun p : ℕ × ℕ => p.2 ≤ N ∧ p.1 ≤ p.2 ∧
      0 < p.2 ∧ Nat.Coprime p.1 p.2)
      (Finset.range (N + 1) ×ˢ Finset.range (N + 1))).card := by
  have h_card : Finset.card (Finset.filter (fun p => p.2 ≤ N ∧ p.1 ≤ p.2 ∧ 0 < p.2 ∧ Nat.Coprime p.1 p.2) (Finset.product (Finset.range (N + 1)) (Finset.range (N + 1)))) = ∑ k ∈ Finset.Ico 1 (N + 1), Nat.totient k + 1 := by
    have h_farey : Finset.filter (fun p => p.2 ≤ N ∧ p.1 ≤ p.2 ∧ 0 < p.2 ∧ Nat.Coprime p.1 p.2) (Finset.product (Finset.range (N + 1)) (Finset.range (N + 1))) = Finset.biUnion (Finset.Ico 1 (N + 1)) (fun k => Finset.image (fun m => (m, k)) (Finset.filter (fun m => Nat.Coprime m k) (Finset.Ico 1 (k + 1)))) ∪ {(0, 1)} := by
      ext ⟨x, y⟩; simp [Finset.mem_biUnion, Finset.mem_image]
      grind
    rw [h_farey, Finset.card_union_of_disjoint] <;> norm_num
    · rw [Finset.card_biUnion]
      · refine Finset.sum_congr rfl fun x hx => ?_
        rw [Finset.card_image_of_injective] <;> norm_num [Function.Injective]
        rcases x with (_ | _ | x) <;> simp_all +decide [Nat.Coprime, Nat.gcd_comm]
        congr 1 with (_ | m) <;> simp +arith +decide [Nat.coprime_comm]
        exact fun _ => ⟨fun h => Nat.le_of_lt_succ <| h.lt_of_ne <| by aesop_cat, fun h => Nat.le_succ_of_le h⟩
      · exact fun a ha b hb hab => Finset.disjoint_left.mpr fun x hx₁ hx₂ => hab <| by aesop
    · aesop
  erw [h_card, add_comm, Finset.sum_Ico_eq_sum_range]; norm_num [add_comm, Finset.sum_range_succ']

/-! ## Part 6: Euler's product formula -/

/-- Euler's product formula: φ(n) = n · ∏_{p | n, p prime} (1 - 1/p).
This shows that the "new radii count" φ(n) is entirely determined by
which primes divide n. -/
theorem totient_eq_euler_product (n : ℕ) (_hn : 0 < n) :
    (n.totient : ℚ) = n * ∏ p ∈ n.primeFactors, (1 - (p : ℚ)⁻¹) :=
  (Nat.totient_eq_mul_prod_factors n).symm ▸ rfl

/-! ## Part 7: Farey Sequence Definitions and the Franel–Landau Criterion

We define the Farey sequence as a finset, the Farey discrepancy (the "wobble"
measuring deviation from uniform distribution), and formally state the
Franel–Landau criterion connecting Farey discrepancy to the Riemann Hypothesis.

This is the first formal statement of the Franel–Landau equivalence in any
proof assistant (Lean, Coq, Isabelle, or otherwise).
-/

/-- The Farey set of order N: all coprime pairs (a, b) with 0 ≤ a ≤ b ≤ N and b > 0.
Each pair (a, b) represents the fraction a/b in the Farey sequence F_N. -/
noncomputable def fareySet (N : ℕ) : Finset (ℕ × ℕ) :=
  (Finset.range (N + 1) ×ˢ Finset.range (N + 1)).filter fun p =>
    0 < p.2 ∧ p.1 ≤ p.2 ∧ p.2 ≤ N ∧ Nat.Coprime p.1 p.2

/-- The cardinality of the Farey set equals 1 + Σ_{k=1}^{N} φ(k).
This connects to `farey_count` above. -/
theorem fareySet_card (N : ℕ) (hN : 0 < N) :
    (fareySet N).card = 1 + ∑ k ∈ Finset.range N, (k + 1).totient := by
  rw [farey_count N hN]
  congr 1
  apply Finset.filter_congr
  intro ⟨x, y⟩ _
  simp only
  tauto

/-- The Farey discrepancy of order N: sum of squared deviations of Farey fractions
from uniform spacing. This is the "wobble" — the quantity that the Riemann
Hypothesis controls.

Formally: D(N) = Σ_{(a,b) ∈ F_N} |a/b - rank(a/b)/|F_N||²

For this definition we use a simplified form: the sum of |(a/b) * |F_N| - rank|²
over all Farey fractions, which avoids division. The rank is approximated by
the natural ordering position. A full formalization would require sorting the
Farey set and computing ranks, which we leave as future work. -/
noncomputable def fareyDiscrepancySquared (N : ℕ) : ℚ :=
  let F := fareySet N
  let size := (F.card : ℚ)
  ∑ p ∈ F, ((p.1 : ℚ) / p.2 - (F.filter fun q =>
    q.1 * p.2 < p.1 * q.2 ∨ (q.1 * p.2 = p.1 * q.2 ∧ q.2 < p.2)).card / size) ^ 2

/-! ### The Franel–Landau Criterion

The Franel–Landau theorem (1924) establishes a remarkable equivalence:

  **The Riemann Hypothesis is true if and only if the Farey discrepancy
  D(N) = O(N^{-1+ε}) for every ε > 0.**

This means: the primes distribute themselves so efficiently that the resulting
Farey sequence (the overlay of all circle divisions) is nearly uniformly
distributed — and the quality of this approximation is equivalent to the
deepest unsolved problem in mathematics.

We state this as a formal proposition connecting the Farey discrepancy
(computable from our circle visualization) to the Riemann Hypothesis
(stated in Mathlib as `RiemannHypothesis`). -/

/-- **Franel–Landau criterion (one direction)**: If the Riemann Hypothesis holds,
then the Farey discrepancy satisfies D(N) = O(N^{-1+ε}) for all ε > 0.

This formalizes the "wobble minimization" interpretation: RH implies that
primes fill gaps in the circle as uniformly as possible. -/
theorem franelLandau_forward :
    RiemannHypothesis →
    ∀ ε : ℝ, 0 < ε → ∃ C : ℝ, 0 < C ∧
      ∀ N : ℕ, 0 < N → (fareyDiscrepancySquared N : ℝ) ≤ C * (N : ℝ) ^ (-(1 : ℝ) + ε) := by
  sorry

/-- **Franel–Landau criterion (reverse direction)**: If the Farey discrepancy
satisfies D(N) = O(N^{-1+ε}) for all ε > 0, then the Riemann Hypothesis holds.

This is the deeper direction: the quality of Farey uniform distribution
*implies* the truth of RH. -/
theorem franelLandau_reverse :
    (∀ ε : ℝ, 0 < ε → ∃ C : ℝ, 0 < C ∧
      ∀ N : ℕ, 0 < N → (fareyDiscrepancySquared N : ℝ) ≤ C * (N : ℝ) ^ (-(1 : ℝ) + ε)) →
    RiemannHypothesis := by
  sorry

/-- **The Franel–Landau equivalence**: The Riemann Hypothesis is equivalent to
the Farey discrepancy satisfying a specific decay bound.

This is the formal bridge between the circle visualization (Farey sequences)
and the Riemann Hypothesis — the first such formal statement in any proof assistant. -/
theorem franelLandau_iff :
    RiemannHypothesis ↔
    ∀ ε : ℝ, 0 < ε → ∃ C : ℝ, 0 < C ∧
      ∀ N : ℕ, 0 < N → (fareyDiscrepancySquared N : ℝ) ≤ C * (N : ℝ) ^ (-(1 : ℝ) + ε) :=
  ⟨franelLandau_forward, franelLandau_reverse⟩

/-! ## Part 8: Mertens Function and RH

The Mertens function M(n) = Σ_{k=1}^{n} μ(k) provides another bridge between
the circle visualization and the Riemann Hypothesis. The Mertens function
counts the "excess" of Farey fractions: it measures how many coprime pairs
are "missing" from perfect distribution.

The equivalence M(x) = O(x^{1/2+ε}) ⟺ RH is a classical result that
complements the Franel–Landau criterion. -/

/-- The Mertens function: M(n) = Σ_{k=1}^{n} μ(k), where μ is the Möbius function. -/
noncomputable def mertensFunction (n : ℕ) : ℤ :=
  ∑ k ∈ Finset.range n, ArithmeticFunction.moebius (k + 1)

/-- **Mertens criterion for RH**: The Riemann Hypothesis is equivalent to
M(n) = O(n^{1/2+ε}) for all ε > 0.

This connects to the Farey visualization because the Mertens function
measures the "error" in counting Farey fractions: the deviation of the
actual Farey count from the asymptotic 3N²/π². -/
theorem mertens_iff_rh :
    RiemannHypothesis ↔
    ∀ ε : ℝ, 0 < ε → ∃ C : ℝ, 0 < C ∧
      ∀ n : ℕ, 0 < n → |((mertensFunction n : ℤ) : ℝ)| ≤ C * (n : ℝ) ^ ((1 : ℝ) / 2 + ε) := by
  sorry

/-! ## Part 9: Farey Symmetry and the Mertens Connection

The Farey sequence F_N is symmetric around 1/2: for every a/b ∈ F_N with
0 < a/b < 1, its complement (b-a)/b is also in F_N. Together with the
endpoints 0 and 1, this gives:

  Σ_{a/b ∈ F_N} a/b = |F_N| / 2

This means the Farey sequence is always *centered*: its mean value is
exactly 1/2. This is the real-valued analogue of the Landau formula

  M(N) = -1 + Σ_{a/b ∈ F_N} exp(2πi · a/b)

which follows from Möbius inversion combined with the fact that the sum
of e-th roots of unity is 0 for e ≥ 2. Numerically verified:
  M(1)=1  (F₁={0,1}: sum exp=1+1=2, 2-1=1 ✓)
  M(2)=0  (F₂={0,½,1}: 1-1+1=1, 1-1=0 ✓)
  M(3)=-1 (F₃={0,⅓,½,⅔,1}: 1+e^{2πi/3}-1+e^{4πi/3}+1=0, 0-1=-1 ✓)

The per-prime wobble decomposition discovered computationally shows that
ΔW(p) > 0 (violations, where adding prime p *decreases* wobble) occurs
precisely when M(p)/√p is large and positive (empirically ≥ 0.175 for
all violations observed up to N=5000). This connects the sign of ΔW(p)
to the size of M(p), and thereby to the Riemann Hypothesis via the
Franel-Landau theorem.
-/

/-
PROBLEM
**Farey Symmetry Theorem**: The Farey sequence F_N is symmetric around 1/2.
For every fraction a/b in F_N with 0 < a/b < 1, its complement (b-a)/b
is also in F_N. As a consequence, the sum of all Farey fractions equals
half the size of the sequence: Σ_{p ∈ F_N} p = |F_N| / 2.

This is the real-valued analogue of Landau's formula M(N) = -1 + Σ e^{2πia}.

PROVIDED SOLUTION
We use `Finset.sum_involution` with the function f(a,b) = (2*(a:ℚ)/b - 1) and the involution g(a,b) = (b-a, b).

Key steps:
1. Rewrite the goal as: ∑ p ∈ fareySet N, (2 * (p.1:ℚ)/p.2 - 1) = 0
   This follows since 2 * ∑ ... = card means ∑ (2*a/b) = card, and card = ∑ 1, so ∑ (2*a/b - 1) = 0.

2. Define g(a,b) = (b-a, b). This is an involution on fareySet N:
   - If (a,b) ∈ fareySet N, then b > 0, a ≤ b, b ≤ N, Coprime a b.
   - Then (b-a) ≤ b (since a ≥ 0 in ℕ), b ≤ N, b > 0.
   - Coprime (b-a) b: gcd(b-a, b) = gcd(a, b) = 1 (since gcd(b-a, b) = gcd(b mod (b-a)... actually just use that gcd(b-a, b) divides b and b-a, so divides a, hence divides gcd(a,b) = 1).
   - g(g(a,b)) = g(b-a, b) = (b-(b-a), b) = (a, b) since a ≤ b.

3. f(a,b) + f(g(a,b)) = (2a/b - 1) + (2(b-a)/b - 1). Since a ≤ b, (b-a : ℚ) = b - a (use Nat.cast_sub). So this equals 2a/b + 2(b-a)/b - 2 = 2a/b + 2b/b - 2a/b - 2 = 2 - 2 = 0.

4. The fixed points of g are where b-a = a, i.e. b = 2a. With coprimality, gcd(a, 2a) = a so a = 1, b = 2. For this point, f(1,2) = 2*(1/2) - 1 = 0. So the condition f(a) ≠ 0 → g(a) ≠ a is satisfied.

So by Finset.sum_involution, ∑ (2*a/b - 1) = 0, giving the result.
-/
theorem farey_sum_eq_half_card (N : ℕ) (hN : 0 < N) :
    2 * ∑ p ∈ fareySet N, (p.1 : ℚ) / p.2 = (fareySet N).card := by
  -- By pairing each fraction with its complement, we can rewrite the sum as a sum over pairs.
  have h_pair : ∑ p ∈ fareySet N, (p.1 : ℚ) / p.2 = ∑ p ∈ fareySet N, ((p.2 - p.1 : ℚ) / p.2) := by
    apply Finset.sum_bij (fun p hp => (p.2 - p.1, p.2));
    · simp +contextual [ fareySet ];
      grind;
    · simp +contextual [ fareySet ];
      intros; omega;
    · unfold fareySet;
      simp +zetaDelta at *;
      exact fun a b ha hb hb' hab hb'' hab' => ⟨ b - a, ⟨ ⟨ Nat.sub_le_of_le_add <| by linarith, hb'' ⟩, hb', Nat.sub_le_of_le_add <| by linarith, hb'', by simpa [ hab ] using hab' ⟩, Nat.sub_sub_self hab ⟩;
    · simp +zetaDelta at *;
      intro a b hab; rw [ Nat.cast_sub ( by linarith [ Finset.mem_filter.mp hab |>.2.2.1 ] ) ] ; ring;
  norm_num [ sub_div ] at h_pair;
  rw [ Finset.sum_congr rfl fun x hx => div_self <| Nat.cast_ne_zero.mpr <| by linarith [ Finset.mem_filter.mp hx ] ] at h_pair ; norm_num at h_pair ; linarith

/-
PROBLEM
**Landau's Farey-Mertens Identity**: The Mertens function M(N) equals -1
plus the sum of complex exponentials exp(2πi·a/b) over all Farey fractions.

  M(N) = -1 + Σ_{a/b ∈ F_N} exp(2πi · a/b)

This follows from Möbius inversion and the fact that the sum of e-th roots
of unity vanishes for e ≥ 2. It is the starting point of the proof of the
Franel-Landau theorem and provides a direct link between the combinatorial
structure of Farey sequences and the analytic Mertens function.

PROVIDED SOLUTION
The proof uses Möbius inversion and the sum of roots of unity.

Step 1: Decompose the sum over fareySet by denominator b.
∑_{(a,b) ∈ fareySet N} exp(2πi a/b) = exp(0) [from (0,1)] + ∑_{b=1}^{N} ∑_{a=1, a≤b, gcd(a,b)=1} exp(2πi a/b)

Step 2: For each b, the inner sum ∑_{a=1, gcd(a,b)=1}^{b} exp(2πi a/b) equals the Ramanujan sum c_b(1) = μ(b).

To prove the Ramanujan sum identity, use:
- ∑_{d|n} μ(d) = [n=1] (Möbius inversion)
- ∑_{a=1}^{n} exp(2πi a/n) = 0 for n ≥ 2 (geometric series / roots of unity)

By Möbius inversion:
∑_{a=1, gcd(a,b)=1}^{b} exp(2πi a/b)
= ∑_{a=1}^{b} (∑_{d|gcd(a,b)} μ(d)) exp(2πi a/b)
= ∑_{d|b} μ(d) ∑_{j=1}^{b/d} exp(2πi j/(b/d))

For b/d ≥ 2, the inner sum is 0. For b/d = 1 (d=b), exp(2πi) = 1.
So the whole sum = μ(b).

Step 3: Therefore the total sum = 1 + ∑_{b=1}^{N} μ(b) = 1 + M(N).
So M(N) = -1 + total sum.
-/
set_option maxHeartbeats 1600000 in
theorem landau_farey_mertens_identity (N : ℕ) (hN : 0 < N) :
    (mertensFunction N : ℂ) =
      -1 + ∑ p ∈ fareySet N,
        Complex.exp (2 * Real.pi * Complex.I * (p.1 : ℂ) / p.2) := by
  -- By definition of $mertensFunction$, we can rewrite the goal in terms of the sum of Möbius functions.
  have h_mertens : (mertensFunction N : ℂ) = ∑ b ∈ Finset.Ico 1 (N + 1), (ArithmeticFunction.moebius b : ℂ) := by
    unfold mertensFunction; simp +decide [ Finset.sum_Ico_eq_sum_range ] ;
    ac_rfl;
  -- By definition of $fareySet$, we can rewrite the goal in terms of the sum of Farey fractions.
  have h_farey : ∑ p ∈ fareySet N, Complex.exp (2 * Real.pi * Complex.I * p.1 / p.2) = 1 + ∑ b ∈ Finset.Ico 1 (N + 1), ∑ a ∈ Finset.filter (fun a => Nat.Coprime a b) (Finset.Ico 1 (b + 1)), Complex.exp (2 * Real.pi * Complex.I * a / b) := by
    rw [ show fareySet N = { ( 0, 1 ) } ∪ ( Finset.biUnion ( Finset.Ico 1 ( N + 1 ) ) fun b => Finset.image ( fun a => ( a, b ) ) ( Finset.filter ( fun a => Nat.Coprime a b ) ( Finset.Ico 1 ( b + 1 ) ) ) ) from ?_, Finset.sum_union ] <;> norm_num;
    · rw [ Finset.sum_biUnion ] ; aesop;
      exact fun a ha b hb hab => Finset.disjoint_left.mpr fun x hx₁ hx₂ => hab <| by aesop;
    · aesop;
    · ext ⟨a, b⟩; simp [fareySet];
      grind +ring;
  -- For each $b$, the inner sum $\sum_{a=1, \gcd(a,b)=1}^{b} e^{2\pi i a/b}$ is equal to $\mu(b)$.
  have h_inner : ∀ b ∈ Finset.Ico 1 (N + 1), ∑ a ∈ Finset.filter (fun a => Nat.Coprime a b) (Finset.Ico 1 (b + 1)), Complex.exp (2 * Real.pi * Complex.I * a / b) = (ArithmeticFunction.moebius b : ℂ) := by
    intro b hb
    have h_inner_sum : ∑ a ∈ Finset.filter (fun a => Nat.Coprime a b) (Finset.Ico 1 (b + 1)), Complex.exp (2 * Real.pi * Complex.I * a / b) = ∑ d ∈ Nat.divisors b, (ArithmeticFunction.moebius d : ℂ) * ∑ a ∈ Finset.filter (fun a => d ∣ a) (Finset.Ico 1 (b + 1)), Complex.exp (2 * Real.pi * Complex.I * a / b) := by
      have h_inner_sum : ∀ a ∈ Finset.Ico 1 (b + 1), (if Nat.Coprime a b then 1 else 0) = ∑ d ∈ Nat.divisors (Nat.gcd a b), (ArithmeticFunction.moebius d : ℂ) := by
        intro a ha
        have h_inner_sum : ∑ d ∈ Nat.divisors (Nat.gcd a b), (ArithmeticFunction.moebius d : ℂ) = if Nat.gcd a b = 1 then 1 else 0 := by
          have h_inner_sum : ∀ n : ℕ, n > 0 → ∑ d ∈ Nat.divisors n, (ArithmeticFunction.moebius d : ℂ) = if n = 1 then 1 else 0 := by
            intro n hn_pos
            have h_inner_sum : ∑ d ∈ Nat.divisors n, (ArithmeticFunction.moebius d : ℂ) = (ArithmeticFunction.moebius * ArithmeticFunction.zeta) n := by
              simp +decide [ ArithmeticFunction.moebius, ArithmeticFunction.zeta ];
              rw [ Nat.sum_divisorsAntidiagonal fun x y => if y = 0 then 0 else if Squarefree x then ( -1 : ℂ ) ^ ArithmeticFunction.cardFactors x else 0 ];
              exact Finset.sum_congr rfl fun x hx => by rw [ if_neg ( Nat.ne_of_gt ( Nat.div_pos ( Nat.le_of_dvd hn_pos ( Nat.dvd_of_mem_divisors hx ) ) ( Nat.pos_of_mem_divisors hx ) ) ) ] ;
            aesop;
          exact h_inner_sum _ ( Nat.gcd_pos_of_pos_left _ ( Finset.mem_Ico.mp ha |>.1 ) )
        rw [h_inner_sum];
      have h_inner_sum : ∑ a ∈ Finset.Ico 1 (b + 1), (if Nat.Coprime a b then 1 else 0) * Complex.exp (2 * Real.pi * Complex.I * a / b) = ∑ d ∈ Nat.divisors b, (ArithmeticFunction.moebius d : ℂ) * ∑ a ∈ Finset.Ico 1 (b + 1), (if d ∣ a then 1 else 0) * Complex.exp (2 * Real.pi * Complex.I * a / b) := by
        have h_inner_sum : ∀ a ∈ Finset.Ico 1 (b + 1), (if Nat.Coprime a b then 1 else 0) * Complex.exp (2 * Real.pi * Complex.I * a / b) = ∑ d ∈ Nat.divisors b, (ArithmeticFunction.moebius d : ℂ) * (if d ∣ a then 1 else 0) * Complex.exp (2 * Real.pi * Complex.I * a / b) := by
          intro a ha; rw [ h_inner_sum a ha ] ; simp +decide [ Finset.sum_mul _ _ _ ] ;
          rw [ ← Finset.sum_filter ];
          rcongr x ; simp +decide [ Nat.dvd_gcd_iff ];
          grind;
        rw [ Finset.sum_congr rfl h_inner_sum, Finset.sum_comm ];
        simp +decide only [mul_assoc, Finset.mul_sum _ _ _];
      simp_all +decide [ Finset.sum_ite ];
    -- For each $d \mid b$, the inner sum $\sum_{a=1, d \mid a}^{b} e^{2\pi i a/b}$ is equal to $\sum_{k=1}^{b/d} e^{2\pi i k/(b/d)}$.
    have h_inner_sum_div : ∀ d ∈ Nat.divisors b, ∑ a ∈ Finset.filter (fun a => d ∣ a) (Finset.Ico 1 (b + 1)), Complex.exp (2 * Real.pi * Complex.I * a / b) = ∑ k ∈ Finset.Ico 1 (b / d + 1), Complex.exp (2 * Real.pi * Complex.I * k / (b / d)) := by
      intros d hd
      have h_inner_sum_div_eq : Finset.filter (fun a => d ∣ a) (Finset.Ico 1 (b + 1)) = Finset.image (fun k => d * k) (Finset.Ico 1 (b / d + 1)) := by
        ext a; simp [Finset.mem_image];
        exact ⟨ fun h => ⟨ a / d, ⟨ Nat.div_pos ( Nat.le_of_dvd h.1.1 h.2 ) ( Nat.pos_of_mem_divisors hd ), Nat.div_le_div_right h.1.2 ⟩, Nat.mul_div_cancel' h.2 ⟩, by rintro ⟨ k, ⟨ hk₁, hk₂ ⟩, rfl ⟩ ; exact ⟨ ⟨ by nlinarith [ Nat.pos_of_mem_divisors hd ], by nlinarith [ Nat.div_mul_le_self b d ] ⟩, by simp +decide ⟩ ⟩;
      simp_all +decide [ Finset.sum_image, mul_div_assoc ];
      rw [ Finset.sum_image ] <;> norm_num [ div_eq_mul_inv, mul_assoc, mul_comm, mul_left_comm, hd.1 ];
      exact fun x hx y hy hxy => mul_left_cancel₀ ( Nat.ne_of_gt ( Nat.pos_of_dvd_of_pos hd.1 hb.1 ) ) hxy;
    -- For each $d \mid b$, the inner sum $\sum_{k=1}^{b/d} e^{2\pi i k/(b/d)}$ is equal to $0$ if $b/d > 1$ and $1$ if $b/d = 1$.
    have h_inner_sum_zero : ∀ d ∈ Nat.divisors b, d ≠ b → ∑ k ∈ Finset.Ico 1 (b / d + 1), Complex.exp (2 * Real.pi * Complex.I * k / (b / d)) = 0 := by
      intros d hd hd_ne_b
      have h_inner_sum_zero : ∑ k ∈ Finset.range (b / d), Complex.exp (2 * Real.pi * Complex.I * k / (b / d)) = 0 := by
        have h_inner_sum_zero : ∑ k ∈ Finset.range (b / d), (Complex.exp (2 * Real.pi * Complex.I / (b / d))) ^ k = 0 := by
          rw [ geom_sum_eq ] <;> norm_num [ Complex.ext_iff, Complex.exp_re, Complex.exp_im ];
          · rw [ ← Complex.exp_nat_mul, mul_comm ] ; norm_num [ Complex.exp_re, Complex.exp_im, div_eq_mul_inv ];
            by_cases hb : b = 0 <;> simp_all +decide [ Nat.cast_div, Nat.dvd_of_mem_divisors ];
            simp +decide [ div_eq_mul_inv, mul_assoc, mul_comm, mul_left_comm, hb, show d ≠ 0 by aesop ];
            norm_num [ mul_two ];
          · norm_num [ div_eq_mul_inv ];
            by_cases hb : b = 0 <;> simp_all +decide [ mul_assoc, mul_comm, mul_left_comm ];
            intro h; rw [ Real.cos_eq_one_iff ] at h; obtain ⟨ k, hk ⟩ := h; simp_all +decide [ mul_assoc, mul_comm Real.pi ] ;
            -- Simplify the equation $k * (2 * π) = d * ((b : ℝ)⁻¹ * (2 * π))$ to get $k * b = d$.
            have h_simplified : k * b = d := by
              exact_mod_cast ( by nlinarith [ Real.pi_pos, mul_inv_cancel_left₀ ( by positivity : ( b : ℝ ) ≠ 0 ) ( 2 * Real.pi ) ] : ( k : ℝ ) * b = d );
            exact False.elim <| hd_ne_b <| by nlinarith [ show k = 1 by nlinarith [ Nat.pos_of_dvd_of_pos hd ( by linarith ), Nat.le_of_dvd ( by linarith ) hd ] ] ;
        exact Eq.trans ( Finset.sum_congr rfl fun _ _ => by rw [ ← Complex.exp_nat_mul ] ; ring ) h_inner_sum_zero;
      rw [ Finset.sum_Ico_eq_sub _ ] <;> norm_num [ h_inner_sum_zero ];
      simp_all +decide [ Finset.sum_range_succ ];
      rw [ mul_div_cancel_right₀ _ ( div_ne_zero ( Nat.cast_ne_zero.mpr hd.2 ) ( Nat.cast_ne_zero.mpr ( by aesop ) ) ) ] ; norm_num [ Complex.exp_nat_mul, mul_div_cancel₀ ];
    rw [ h_inner_sum, Finset.sum_eq_single b ];
    · rw [ Finset.sum_eq_single b ] <;> norm_num;
      · norm_num [ show b ≠ 0 by linarith [ Finset.mem_Ico.mp hb ] ];
      · exact fun x hx₁ hx₂ hx₃ => le_antisymm hx₂ ( Nat.le_of_dvd hx₁ hx₃ );
      · linarith [ Finset.mem_Ico.mp hb ];
    · exact fun d hd hd' => by rw [ h_inner_sum_div d hd, h_inner_sum_zero d hd hd' ] ; ring;
    · aesop;
  rw [ h_mertens, h_farey, Finset.sum_congr rfl h_inner ] ; norm_num